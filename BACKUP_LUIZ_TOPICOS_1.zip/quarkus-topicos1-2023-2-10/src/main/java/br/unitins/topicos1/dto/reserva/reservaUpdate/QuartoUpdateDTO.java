package br.unitins.topicos1.dto.reserva.reservaUpdate;

public record QuartoUpdateDTO(
        Long id) {

}
